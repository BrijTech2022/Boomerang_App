export const loginState = {
    isLoggedIn: false,
     CName: "",
     CAddress:"",
     CEmail:"",
     token: '',
     refreshToken: '',
     expiresOn: '',
     data: '',
  };
export const FCMToken={
Token:""
}