export const SET_LOGIN_STATE = "SET_LOGIN_STATE"
export const LOG_OUT="LOG_OUT"
export const SET_FCM_TOKEN="SET_FCM_TOKEN"