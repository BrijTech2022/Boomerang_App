

const cUrl="https://restapi.kiezensoft.co.in/api/User_Login/getcolor";
getcolor();
export function getcolor(){
 //alert( JSON.stringify(props))
 //const [color,setColor]=useState('#eb6b40')
 
//  fetch(cUrl, {
//         method: "GET",
//         headers: {  // these could be different for your API call
//           Accept: 'application/json',
//           'Content-Type': 'application/json',
//         },
//         //body: jsonbody,
//       })
//         .then((response) => response.json())
//         .then((json) => { 
//           //alert(json.data[0].Color)
//          //takeColor(json.data[0].Color);
//          themeColor=json.data[0].Color;

       
//         //themeColor='#'+props.Myenv.Color;
//         })
//         .catch((err) => {
//            notifyMessage('Some error occured, please retry');
         
//            console.log(err);
//            takeColor('#eb6b40')
//         });
    
 }
 
 
// export var themeColor='#a3238e';         // Deep Magenta
// export var themeColor='#40826D';        //veredian green
// export var themeColor='#ef1e0a';        //veredian red
// export var themeColor='#ff671f';        // kesariya

// export var themeColor='#B881EA';     // purple
// export var themeColor='#1560bd'         // denim blue  
export var themeColor='#002954';        // Dark blue
// export var themeColor='#000080';     // Navi blue

export var themeText='#002954'         // Dark blue
export var whiteText='#FFFFFF'

// export var backColor='#F3F7FB';
export var backColor='white';

export var sGreen='#B881EA';
// export var sGreen='#2AAA8A';

export var buyColor='#2AAA8A';



  
  