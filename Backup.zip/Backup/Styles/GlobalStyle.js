import {
    StyleSheet,
  } from 'react-native';
import { themeColor } from './Color';
export const Globalstyles = StyleSheet.create({
    // inputs:{
    //     height:45,
    //     marginLeft:16,
    //     borderBottomColor:themeColor,
    //     flex:1,
        
    // },
    // inputIcon:{
    //   width:30,
    //   height:30,
    //   marginLeft:15,
    //   marginTop:20,
    //   justifyContent: 'center'
    // },
    // buttonContainer: {
    //   height:45,
    //   flexDirection: 'row',
    //   justifyContent: 'center',
    //   alignItems: 'center',
    //   marginBottom:30,
    //   width:250,
    //   borderRadius:30,
    // },
    // loginButton: {
    //   backgroundColor: themeColor,
    //   marginTop:-90,
    // },
    // loginText: {
    //   color: 'white',
    //   fontWeight:"bold"
    // },
    // logo:{
    //     width:84,
    //     height:90,
    // },

    msgStyle:{
      color:"red",
      fontSize:13
    }

})