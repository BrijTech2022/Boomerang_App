export var baseURL="https://api.boomerang.net.in/api/";
export var imageUrl="https://boomerang.net.in/";
// export var token=this.props.loginInfo.UserInfo.token;
export var token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJUZXN0MiIsIm5iZiI6MTcxMTg3MjQ2MCwiZXhwIjoxNzExODc5NjYwLCJpYXQiOjE3MTE4NzI0NjAsImlzcyI6ImJvb21yYW5nLm5ldC5pbiIsImF1ZCI6ImJvb21yYW5nLm5ldC5pbiJ9.LZAF-fuIF5D2sC9P74CeUn8Qgt-92vEV9AUWyQNjIdk";
export var audioURL='https://pwdown.info/113725/variation/190K/Rabba%20Janda%20-%20Jubin%20Nautiyal.mp3'
